const $ = (id) => document.getElementById(id);
const h = GM.h;

let mainText = ""; // „Wszystkie maile” (czarny prostokąt)
let groups = [];
let folders = [];
let folderId = null; // aktualny katalog
let current = "main"; // "all" = Wszystkie maile, "main" = główna grupa katalogu, albo id grupy
let customColors = []; // zapisane własne kolory
let allFiles = []; // pliki Word wczytane do „Wszystkich maili”
let allOpen = false; // czy czarny prostokąt jest wysunięty

const curFolder = () => folders.find((f) => f.id === folderId) || folders[0] || null;
const curGroup = () => (current === "main" || current === "all" ? null : groups.find((g) => g.id === current) || null);
const curStored = () => {
  if (current === "all") return mainText;
  const g = curGroup();
  return g ? g.text : (curFolder() || {}).mainText || "";
};
// Obiekt przechowujący listę plików Word dla aktualnie otwartej listy.
const filesOwner = () => curGroup() || (current === "all" ? null : curFolder());
const curFiles = () => (current === "all" ? allFiles : (filesOwner() || {}).files || []);
const isDirty = () => $("text").value !== curStored();
// Autozapis: tekst zapisuje się sam chwilę po wpisaniu; adresy trafiają do nadrzędnych list przy „Zapisz”,
// przy zmianie listy/katalogu i przy zamknięciu okna (pendingPropagate = jeszcze nie rozesłane).
let autoTimer = null;
let pendingPropagate = false;
const needsCommit = () => $("text").value.trim() !== "" && (isDirty() || pendingPropagate);

function setStatus(text, warn) {
  const s = $("status");
  s.textContent = text;
  s.classList.toggle("warn", !!warn);
}

/* ---------- Kolumna z listami ---------- */

function makeSquare({ label, icon, color, active, title, onClick }) {
  const b = h(
    "button",
    { type: "button", class: "sq" + (active ? " active" : ""), title: title || label, style: { background: color, color: GM.inkOn(color) } },
    [GM.icon(icon, 20), h("span", { class: "nm", text: label })]
  );
  b.addEventListener("click", onClick);
  return b;
}

function renderFolders() {
  const box = $("folderList");
  box.textContent = "";
  folders.forEach((f) => {
    const on = f.id === folderId;
    const b = h("button", { type: "button", class: "ftile" + (on ? " active" : ""), title: f.name, style: { background: GM.tint(f.color, on ? 0.5 : 0.28) } }, [
      on ? h("small", { text: "aktualnie" }) : null,
      GM.icon("folder", 16),
      h("span", { text: f.name })
    ]);
    b.addEventListener("click", () => selectFolder(f.id));
    box.appendChild(b);
  });
}

function renderSide() {
  const f = curFolder();
  renderFolders();
  // główna grupa katalogu (białe tło, nazwa katalogu w drugiej linijce)
  const slot = $("mainSlot");
  slot.textContent = "";
  const mainSq = makeSquare({ label: "", icon: "folder", color: "#fff", active: current === "main", onClick: () => selectList("main") });
  mainSq.title = GM.mainLabel(f);
  const nm = mainSq.querySelector(".nm");
  nm.appendChild(h("b", { text: "Główna grupa" }));
  nm.appendChild(h("span", { text: f ? f.name : "" }));
  mainSq.classList.add("main-sq");
  slot.appendChild(mainSq);
  // uchwyt „Wszystkie maile”
  $("dBody").classList.toggle("active", current === "all");
  $("dCount").textContent = `adresów: ${GM.entriesOf(mainText).length}`;

  const box = $("groupSquares");
  box.textContent = "";
  const list = groups.filter((g) => g.folderId === folderId);
  list.forEach((g) => {
    box.appendChild(
      makeSquare({
        label: g.name,
        icon: g.icon,
        color: g.color,
        active: g.id === current,
        title: `${g.name} (adresów: ${GM.groupEmails(g).length})`,
        onClick: () => selectList(g.id)
      })
    );
  });
  if (!list.length) box.appendChild(h("div", { style: { padding: "4px 12px 10px", fontSize: "12px", color: "#5f6368", lineHeight: "1.4" }, text: "Brak grup w tym katalogu." }));
}

async function selectFolder(id) {
  closePanel();
  if (id === folderId && current === "main") return;
  if (needsCommit()) await saveCurrent(true);
  folderId = id;
  current = "main"; // po zmianie katalogu pokazujemy jego główną grupę
  render();
}

/* ---------- Pole tekstowe ---------- */

function paintEditor() {
  const g = curGroup();
  const ta = $("text");
  if (g) {
    ta.style.background = GM.tint(g.color, 0.16);
    ta.style.borderColor = GM.tint(g.color, 0.6);
    ta.style.setProperty("--ring", GM.tint(g.color, 0.35));
    ta.setAttribute("data-tinted", "1");
  } else {
    ta.style.background = "#fff";
    ta.style.borderColor = "";
    ta.style.removeProperty("--ring");
    ta.removeAttribute("data-tinted");
  }
  $("listLabel").textContent = g
    ? `${g.name} — adresy`
    : current === "all"
    ? `${GM.ALL_NAME} — adresy`
    : `${GM.mainLabel(curFolder())} — adresy`;
  $("editBtn").hidden = current === "all";
  $("editBtn").title = g ? "Edytuj grupę" : "Edytuj katalog";
}

function loadText() {
  hideSuggest();
  renderFiles();
  $("text").value = curStored();
  setStatus("");
}

function render() {
  renderSide();
  paintEditor();
  loadText();
}

async function selectList(id) {
  closePanel();
  if (id === current) return;
  if (needsCommit()) await saveCurrent(true); // nie gubimy wpisanych adresów przy przełączaniu
  current = id;
  render();
  $("text").focus();
}

async function saveCurrent(silent) {
  clearTimeout(autoTimer);
  pendingPropagate = false;
  const v = $("text").value;
  const g = curGroup();
  const { entries, invalid } = GM.parseEntries(v);
  if (g) {
    g.text = v;
    // adresy wpisane w grupie trafiają też do głównej grupy jej katalogu
    GM.addToFolderMain({ folders }, g.folderId, entries);
    mainText = GM.appendToText(mainText, entries).text; // i do „Wszystkich maili”
    await GM.save({ groups, folders, mainText });
  } else if (current === "all") {
    mainText = v;
    await GM.save({ mainText });
  } else {
    curFolder().mainText = v;
    mainText = GM.appendToText(mainText, entries).text; // adresy z głównej grupy też do „Wszystkich maili”
    await GM.save({ folders, mainText });
  }
  if (silent) return;
  const n = new Set(entries.map((e) => e.email)).size;
  let msg = `Zapisano · adresów: ${n}`;
  if (invalid) msg += `, pominięto błędnych fragmentów: ${invalid}`;
  setStatus(msg, !!invalid);
  renderSide();
}

$("saveBtn").addEventListener("click", () => saveCurrent(false));

$("clearBtn").addEventListener("click", () => {
  $("text").value = "";
  setStatus("Pole wyczyszczone — kliknij Zapisz, aby zatwierdzić.");
  $("text").focus();
});

async function autoSave() {
  if (!isDirty() || $("text").value.trim() === "") return; // pusty tekst zatwierdzasz ręcznie przyciskiem Zapisz
  await persistCurrentOnly();
  pendingPropagate = true;
  setStatus("Zapisano automatycznie");
}

// Zamknięcie okna rozszerzenia: dokończ zapis (łącznie z dopisaniem adresów do głównych list).
const flushOnClose = () => {
  clearTimeout(autoTimer);
  if (needsCommit()) saveCurrent(true);
};
window.addEventListener("pagehide", flushOnClose);
document.addEventListener("visibilitychange", () => document.visibilityState === "hidden" && flushOnClose());

$("text").addEventListener("input", () => {
  clearTimeout(autoTimer);
  autoTimer = setTimeout(autoSave, 600);
  setStatus(isDirty() ? "Niezapisane zmiany" : "");
  updateSuggest();
});

/* ---------- Podpowiedzi z głównej listy (w grupach) ---------- */

let suggestions = [];
let activeIdx = 0;

// Fragment, który użytkownik właśnie pisze (od ostatniego przecinka/średnika/nowej linii do kursora).
function currentToken() {
  const ta = $("text");
  const before = ta.value.slice(0, ta.selectionStart);
  const raw = before.split(/[,;\n]/).pop();
  return { raw, start: ta.selectionStart - raw.length, end: ta.selectionStart };
}

// Pozycja kursora w polu tekstowym (kopia pola ukryta na stronie), żeby podpowiedzi były tuż pod pisanym tekstem.
function caretXY(ta) {
  const cs = getComputedStyle(ta);
  const m = document.createElement("div");
  ["fontFamily", "fontSize", "fontWeight", "lineHeight", "letterSpacing", "paddingTop", "paddingRight", "paddingBottom", "paddingLeft"].forEach((k) => (m.style[k] = cs[k]));
  m.style.cssText += ";position:absolute;visibility:hidden;top:0;left:0;white-space:pre-wrap;word-wrap:break-word;overflow:hidden;box-sizing:content-box;border:0;";
  m.style.width = ta.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight) + "px";
  m.textContent = ta.value.slice(0, ta.selectionStart);
  const s = document.createElement("span");
  s.textContent = "\u200b";
  m.appendChild(s);
  document.body.appendChild(m);
  const lh = parseFloat(cs.lineHeight) || parseFloat(cs.fontSize) * 1.3;
  const r = { top: s.offsetTop, left: s.offsetLeft, lh };
  m.remove();
  return r;
}

function hideSuggest() {
  suggestions = [];
  activeIdx = 0;
  $("suggest").textContent = "";
  $("suggest").hidden = true;
}

function paintActive() {
  [...$("suggest").children].forEach((li, i) => li.classList.toggle("active", i === activeIdx));
}

function updateSuggest() {
  if (current === "main" || current === "all") return hideSuggest();
  const ta = $("text");
  const q = currentToken().raw.trim();
  const used = new Set(GM.entriesOf(ta.value).map((e) => e.email));
  suggestions = q ? GM.gatherSuggestions({ mainText, groups, folders, group: curGroup(), usedEmails: [...used] }, q).items : [];
  activeIdx = 0;
  const ul = $("suggest");
  ul.textContent = "";
  ul.hidden = !suggestions.length;
  if (!suggestions.length) return;
  suggestions.forEach((c, i) => {
    const li = h("li", { class: i === 0 ? "active" : "" }, [h("strong", { text: c.name || c.email }), c.name ? h("span", { text: "  " + c.email }) : null]);
    li.addEventListener("mousedown", (e) => {
      e.preventDefault();
      acceptSuggestion(c);
    });
    ul.appendChild(li);
  });
  // tuż pod linijką z kursorem
  const wrap = ul.parentElement;
  const pos = caretXY(ta);
  const top = Math.min(ta.offsetTop + pos.top - ta.scrollTop + pos.lh + 2, ta.offsetHeight - 4);
  const left = Math.max(0, Math.min(pos.left - ta.scrollLeft + 10, wrap.clientWidth - ul.offsetWidth));
  ul.style.top = (Number.isFinite(top) ? top : ta.offsetHeight) + "px";
  ul.style.left = (Number.isFinite(left) ? left : 0) + "px";
}

function acceptSuggestion(c) {
  const ta = $("text");
  const { raw, start, end } = currentToken();
  const lead = raw.match(/^\s*/)[0];
  const ins = lead + GM.fmtEntry(c) + ", ";
  ta.value = ta.value.slice(0, start) + ins + ta.value.slice(end);
  const pos = start + ins.length;
  ta.setSelectionRange(pos, pos);
  hideSuggest();
  setStatus(isDirty() ? "Niezapisane zmiany" : "");
  ta.focus();
}

$("text").addEventListener("keydown", (e) => {
  if (!suggestions.length) return;
  if (e.key === "ArrowDown") {
    e.preventDefault();
    activeIdx = (activeIdx + 1) % suggestions.length;
    paintActive();
  } else if (e.key === "ArrowUp") {
    e.preventDefault();
    activeIdx = (activeIdx - 1 + suggestions.length) % suggestions.length;
    paintActive();
  } else if (e.key === "Enter" || e.key === "Tab") {
    e.preventDefault();
    acceptSuggestion(suggestions[activeIdx]);
  } else if (e.key === "Escape") {
    e.stopPropagation();
    hideSuggest();
  }
});
$("text").addEventListener("click", updateSuggest);
$("text").addEventListener("blur", () => setTimeout(hideSuggest, 120));

/* ---------- Małe okienko grupy (tworzenie / edycja) ---------- */

function closePanel() {
  $("panel").hidden = true;
  $("panel").textContent = "";
}

function openPanel(g) {
  closePanel();
  const form = GM.groupForm({
    customColors,
    onCustomColors: (c) => {
      customColors = c;
      GM.save({ customColors });
    },
    title: g ? "Edytuj grupę" : "Nowa grupa",
    name: g ? g.name : "",
    icon: g ? g.icon : GM.nextIcon(groups),
    color: g ? g.color : GM.nextColor(groups),
    saveLabel: g ? "Zapisz" : "Utwórz",
    onCancel: closePanel,
    onSave: async (v) => {
      if (g) {
        g.name = v.name || g.name;
        g.icon = v.icon;
        g.color = v.color;
        await GM.save({ groups });
        closePanel();
        renderSide();
        paintEditor();
      } else {
        const ng = { id: GM.newId(), name: v.name || `Grupa ${groups.length + 1}`, icon: v.icon, color: v.color, text: "", folderId };
        groups.push(ng);
        await GM.save({ groups });
        await selectList(ng.id);
      }
    },
    onDelete: g
      ? async () => {
          if (!confirm(`Usunąć grupę „${g.name}” razem z jej adresami?`)) return;
          groups = groups.filter((x) => x.id !== g.id);
          await GM.save({ groups });
          closePanel();
          current = "main";
          render();
        }
      : null
  });
  $("panel").appendChild(form);
  $("panel").hidden = false;
  form.focusName();
}

/* ---------- Małe okienko katalogu (tworzenie / edycja) ---------- */

function openFolderPanel(f) {
  closePanel();
  const form = GM.groupForm({
    title: f ? "Edytuj katalog" : "Nowy katalog",
    name: f ? f.name : "",
    color: f ? f.color : GM.nextColor(folders),
    noIcon: true,
    customColors,
    onCustomColors: (c) => {
      customColors = c;
      GM.save({ customColors });
    },
    nameLabel: "Nazwa katalogu",
    placeholder: "Np. rodzice 9E",
    saveLabel: f ? "Zapisz" : "Utwórz",
    onCancel: closePanel,
    onSave: async (v) => {
      if (f) {
        f.name = v.name || f.name;
        f.color = v.color;
        await GM.save({ folders });
        closePanel();
        render();
      } else {
        if (needsCommit()) await saveCurrent(true);
        const nf = { id: GM.newId(), name: v.name || `Katalog ${folders.length + 1}`, color: v.color, mainText: "" };
        folders.push(nf);
        await GM.save({ folders });
        closePanel();
        folderId = nf.id;
        current = "main";
        render();
      }
    },
    onDelete:
      f && folders.length > 1
        ? async () => {
            const n = groups.filter((g) => g.folderId === f.id).length;
            if (!confirm(`Usunąć katalog „${f.name}” razem z jego grupami (${n}) i główną grupą? „${GM.ALL_NAME}” zostają bez zmian.`)) return;
            groups = groups.filter((g) => g.folderId !== f.id);
            folders = folders.filter((x) => x.id !== f.id);
            await GM.save({ folders, groups });
            closePanel();
            folderId = folders[0].id;
            current = "main";
            render();
          }
        : null
  });
  $("panel").appendChild(form);
  $("panel").hidden = false;
  form.focusName();
}

$("newGroupBtn").addEventListener("click", () => ($("panel").hidden ? openPanel(null) : closePanel()));
$("newFolderBtn").addEventListener("click", () => ($("panel").hidden ? openFolderPanel(null) : closePanel()));
$("editBtn").addEventListener("click", () => {
  const g = curGroup();
  if (g) openPanel(g);
  else if (current === "main") openFolderPanel(curFolder());
});
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") closePanel();
});

/* ---------- Import adresów z pliku Word (.docx) ---------- */

// Zapisuje wyłącznie otwartą listę (bez dopisywania adresów do innych list).
async function persistCurrentOnly() {
  const v = $("text").value;
  const g = curGroup();
  if (g) {
    g.text = v;
    await GM.save({ groups });
  } else if (current === "all") {
    mainText = v;
    await GM.save({ mainText, allFiles });
  } else {
    curFolder().mainText = v;
    await GM.save({ folders });
  }
}

function renderFiles() {
  const box = $("files");
  box.textContent = "";
  curFiles().forEach((f) => {
    const x = h("button", { type: "button", class: "x", title: "Usuń plik i wczytane z niego adresy z tej listy", text: "×" });
    x.addEventListener("click", () => removeFile(f.id));
    box.appendChild(h("span", { class: "chip", title: `${f.name} — adresów z pliku: ${f.added.length}` }, [GM.icon("file", 14), h("span", { class: "nm", text: f.name }), x]));
  });
}

async function importDocx(file) {
  let emails;
  try {
    emails = await GM.docxEmails(await file.arrayBuffer());
  } catch (e) {
    setStatus(`Nie udało się odczytać „${file.name}”: to musi być plik Word .docx (np. Word 2007).`, true);
    return;
  }
  if (!emails.length) {
    setStatus(`W pliku „${file.name}” nie znaleziono adresów e-mail.`, true);
    return;
  }
  const ta = $("text");
  const fresh = emails; // powtórzenia z pliku zostają w polu tekstowym
  ta.value = GM.appendRaw(ta.value, fresh);
  const rec = { id: GM.newId(), name: file.name, added: fresh };
  if (current === "all") allFiles.push(rec);
  else (filesOwner().files = filesOwner().files || []).push(rec);
  await persistCurrentOnly();
  renderFiles();
  renderSide();
  const uniq = new Set(fresh).size;
  setStatus(`Z „${file.name}” dodano ${fresh.length} adresów` + (uniq < fresh.length ? ` (w tym ${fresh.length - uniq} powtórzeń, tak jak w pliku)` : "") + ".");
}

async function removeFile(id) {
  const list = curFiles();
  const f = list.find((x) => x.id === id);
  if (!f) return;
  $("text").value = GM.removeEmails($("text").value, f.added);
  const left = list.filter((x) => x.id !== id);
  if (current === "all") allFiles = left;
  else filesOwner().files = left;
  await persistCurrentOnly();
  renderFiles();
  renderSide();
  setStatus(`Usunięto „${f.name}” i ${f.added.length} adresów z tej listy.`);
}

$("wordBtn").addEventListener("click", () => $("wordFile").click());
$("wordFile").addEventListener("change", async (e) => {
  const files = [...e.target.files];
  e.target.value = "";
  for (const f of files) await importDocx(f);
});

/* ---------- Wysuwany uchwyt „Wszystkie maile” ---------- */

function initDrawer() {
  const dr = $("drawer");
  const handle = $("dHandle");
  const HANDLE = 12;
  let open = false;
  let start = null;
  const closedX = () => dr.offsetWidth - HANDLE;
  const setOpen = (v) => {
    open = v;
    dr.classList.toggle("open", open);
    dr.style.transform = "";
  };
  handle.addEventListener("pointerdown", (e) => {
    handle.setPointerCapture(e.pointerId);
    start = { x: e.clientX, off: open ? 0 : closedX(), moved: false, id: e.pointerId };
    dr.classList.add("dragging");
    dr.style.transform = `translateX(${start.off}px)`;
  });
  handle.addEventListener("pointermove", (e) => {
    if (!start || e.pointerId !== start.id) return;
    const dx = e.clientX - start.x;
    if (Math.abs(dx) > 3) start.moved = true;
    const off = Math.min(closedX(), Math.max(0, start.off + dx)); // przeciąganie w lewo wysuwa, w prawo chowa
    dr.style.transform = `translateX(${off}px)`;
    start.cur = off;
  });
  const end = (e) => {
    if (!start || e.pointerId !== start.id) return;
    dr.classList.remove("dragging");
    const wantOpen = start.moved ? start.cur < closedX() / 2 : !open; // samo kliknięcie przełącza
    start = null;
    setOpen(wantOpen);
  };
  handle.addEventListener("pointerup", end);
  handle.addEventListener("pointercancel", end);
  $("dBody").addEventListener("click", () => selectList("all"));
}

/* ---------- Start ---------- */

(async function init() {
  $("plusIcon").appendChild(GM.icon("plus", 16));
  $("plusIcon2").appendChild(GM.icon("plus", 16));
  $("dIcon").appendChild(GM.icon("mail", 20));
  $("wordIcon").appendChild(GM.icon("file", 15));
  initDrawer();
  $("editBtn").appendChild(GM.icon("pencil", 15));
  $("lockIcon").appendChild(GM.icon("lock", 13));
  await GM.syncIcons(); // ikony z folderu icons/groups
  const s = await GM.load();
  mainText = s.mainText;
  groups = s.groups;
  folders = s.folders;
  allFiles = s.allFiles;
  customColors = s.customColors;
  folderId = folders[0].id;
  render();
})();
