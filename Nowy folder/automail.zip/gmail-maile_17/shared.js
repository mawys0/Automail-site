// Wspólny kod: używany przez popup i przez skrypt działający w Gmailu.
(function (root) {
  const COLORS = ["#f0089a", "#2cc0f5", "#26d100", "#ff6a00", "#6a0dc8", "#ffe600", "#e5251b", "#8d5a3b"];
  const EMAIL_RE = /^[^\s@,;<>"]+@[^\s@,;<>"]+\.[^\s@,;<>"]+$/;
  const FONT = "'Google Sans', 'Segoe UI', Roboto, Arial, sans-serif";
  const ALL_NAME = "Wszystkie maile"; // czarny prostokąt: dawna „Główna lista” (wszystkie adresy)
  const ALL_COLOR = "#202124";
  const mainLabel = (folder) => "Główna grupa " + (folder ? folder.name : ""); // bez dwukropka

  /* ---------- Ikony (obrazki SVG, rysowane kreską – przyjmują kolor tekstu) ---------- */

  const ICONS = {
    mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
    trip: '<rect x="4" y="8" width="16" height="12" rx="2"/><path d="M9 8V5.5A1.5 1.5 0 0 1 10.5 4h3A1.5 1.5 0 0 1 15 5.5V8M9 12v4M15 12v4"/>',
    plane: '<path d="M22 2 11 13"/><path d="M22 2l-7 20-4-9-9-4z"/>',
    mountain: '<path d="M2 20 9 7l5 8 3-4 5 9z"/>',
    tie: '<path d="M9.5 3h5L13 7l2.5 11L12 21l-3.5-3L11 7z"/>',
    work: '<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M9 7V5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2M3 13h18"/>',
    home: '<path d="M3 11 12 3l9 8"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/>',
    heart: '<path d="M12 21s-8-5.2-8-11a4.5 4.5 0 0 1 8-2.8A4.5 4.5 0 0 1 20 10c0 5.8-8 11-8 11z"/>',
    star: '<path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
    users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6"/><circle cx="17.5" cy="9" r="2.5"/><path d="M17 14.2c2.6.3 4.5 2.2 4.5 5.3"/>',
    book: '<path d="M4 19V5a2 2 0 0 1 2-2h14v14H6a2 2 0 0 0-2 2z"/><path d="M4 19a2 2 0 0 0 2 2h14v-4"/>',
    cap: '<path d="M2 9 12 4l10 5-10 5z"/><path d="M6 11.5V16c0 1.5 3 3 6 3s6-1.5 6-3v-4.5"/>',
    cart: '<circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/><path d="M2 3h3l2.6 12.4a1 1 0 0 0 1 .8H18a1 1 0 0 0 1-.8L21 7H6"/>',
    music: '<path d="M9 18V5l11-2v13"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="17.5" cy="16" r="2.5"/>',
    ball: '<circle cx="12" cy="12" r="9"/><path d="M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18M3 12h18"/>',
    car: '<path d="M3 16v-4l2-5h14l2 5v4z"/><path d="M3 12h18"/><circle cx="7.5" cy="16.5" r="1.8"/><circle cx="16.5" cy="16.5" r="1.8"/>',
    paw: '<circle cx="6" cy="10" r="2"/><circle cx="10" cy="6" r="2"/><circle cx="14" cy="6" r="2"/><circle cx="18" cy="10" r="2"/><path d="M12 12c-3 0-5.5 3-5.5 5.2 0 1.6 1.4 2.3 3 2.3 1 0 1.7-.5 2.5-.5s1.5.5 2.5.5c1.6 0 3-.7 3-2.3C17.5 15 15 12 12 12z"/>',
    cake: '<path d="M4 20h16v-7a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2z"/><path d="M4 16c2 1.5 4 1.5 8 0s6-1.5 8 0"/><path d="M12 11V7M12 4v.5"/>',
    gift: '<rect x="3" y="8" width="18" height="4" rx="1"/><path d="M5 12v8h14v-8M12 8v12"/><path d="M12 8c-1-3-5-4-5-1.5S10 8 12 8zM12 8c1-3 5-4 5-1.5S14 8 12 8z"/>',
    coffee: '<path d="M4 8h13v6a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5z"/><path d="M17 10h1.5a2.5 2.5 0 0 1 0 5H17"/><path d="M8 3v2M12 3v2"/>',
    camera: '<path d="M3 8a2 2 0 0 1 2-2h2l1.5-2h7L17 6h2a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><circle cx="12" cy="13" r="3.5"/>',
    game: '<rect x="2" y="7" width="20" height="11" rx="5"/><path d="M7 10.5v4M5 12.5h4M16 11v.01M18.5 13.5v.01"/>',
    bell: '<path d="M6 16v-5a6 6 0 0 1 12 0v5l2 2H4z"/><path d="M10 21h4"/>',
    folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
    // tylko do interfejsu (nie w wyborze ikon grupy)
    file: '<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4"/><path d="m9 12 1.2 5 1.8-4.5 1.8 4.5 1.2-5"/>',
    chev: '<path d="m9 6 6 6-6 6"/>',
    pencil: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="m13.5 6.5 4 4"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    lock: '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>'
  };
  const GROUP_ICONS = ["mail", "trip", "plane", "mountain", "tie", "work", "home", "heart", "star", "users", "book", "cap", "cart", "music", "ball", "car", "paw", "cake", "gift", "coffee", "camera", "game", "bell", "folder"];

  const SVGNS = "http://www.w3.org/2000/svg";

  // Ikony grup z folderu icons/groups: { "plane.svg": {t:"svg", v:"<svg…"}, "moja.png": {t:"img", v:"data:…"} }.
  // Okno rozszerzenia skanuje folder i zapisuje wynik, a skrypt w Gmailu czyta go z pamięci przeglądarki.
  let iconData = {};
  let userIcons = {}; // ikony dodane przez użytkownika w oknie rozszerzenia (klucze zaczynają się od "moje-")
  const sortNames = (o) => Object.keys(o).sort((a, b) => a.localeCompare(b, "pl", { numeric: true }));
  const iconNames = () => {
    const n = sortNames(iconData);
    return [...(n.length || Object.keys(userIcons).length ? n : GROUP_ICONS), ...sortNames(userIcons)];
  };
  const isUserIcon = (id) => Object.prototype.hasOwnProperty.call(userIcons, id);
  const iconTitle = (id) => String(id).replace(/\.[^.]+$/, "");

  // Rysuje SVG z pliku bez innerHTML: usuwa skrypty i zdarzenia, a ikony jednokolorowe barwi na kolor tekstu.
  function svgFromText(text, size) {
    const doc = new DOMParser().parseFromString(text, "image/svg+xml");
    const root = doc.documentElement;
    if (!root || root.nodeName !== "svg" || doc.querySelector("parsererror")) throw new Error("bad svg");
    doc.querySelectorAll("script,foreignObject,iframe,style").forEach((n) => n.remove());
    doc.querySelectorAll("*").forEach((n) => {
      [...n.attributes].forEach((a) => {
        const v = a.value.trim().toLowerCase();
        if (/^on/i.test(a.name) || ((a.name === "href" || a.name === "xlink:href") && !v.startsWith("#") && !v.startsWith("data:image/"))) n.removeAttribute(a.name);
      });
    });
    const svg = document.createElementNS(SVGNS, "svg");
    svg.setAttribute("viewBox", root.getAttribute("viewBox") || `0 0 ${parseFloat(root.getAttribute("width")) || 24} ${parseFloat(root.getAttribute("height")) || 24}`);
    svg.setAttribute("width", size);
    svg.setAttribute("height", size);
    svg.setAttribute("aria-hidden", "true");
    ["fill", "stroke", "stroke-width", "stroke-linecap", "stroke-linejoin"].forEach((k) => root.hasAttribute(k) && svg.setAttribute(k, root.getAttribute(k)));
    const hasCur = /currentColor/i.test(text);
    const hasColor = /#[0-9a-f]{3,8}\b|rgba?\(|(fill|stroke)\s*[=:]\s*["']?(red|blue|green|black|white|orange|yellow|purple|pink|gray|grey|brown)/i.test(text);
    if (!hasCur && !hasColor && !root.hasAttribute("fill") && !root.hasAttribute("stroke")) svg.setAttribute("fill", "currentColor");
    [...root.childNodes].forEach((c) => svg.appendChild(document.importNode(c, true)));
    svg.style.flex = "0 0 auto";
    svg.style.display = "block";
    return svg;
  }

  // Buduje element SVG bez innerHTML (działa też na stronach z ostrą polityką bezpieczeństwa).
  function icon(id, size) {
    size = size || 18;
    const d = userIcons[id] || iconData[id] || iconData[id + ".svg"];
    if (d && d.t === "svg") {
      try {
        return svgFromText(d.v, size);
      } catch (e) {}
    } else if (d && d.t === "img") {
      const im = document.createElement("img");
      im.src = d.v;
      im.alt = "";
      im.width = size;
      im.height = size;
      im.style.cssText = "flex:0 0 auto;display:block;object-fit:contain";
      return im;
    }
    const markup = ICONS[id] || ICONS.mail;
    const svg = document.createElementNS(SVGNS, "svg");
    const set = (el, o) => Object.entries(o).forEach(([k, v]) => el.setAttribute(k, v));
    set(svg, { viewBox: "0 0 24 24", width: size || 18, height: size || 18, fill: "none", stroke: "currentColor", "stroke-width": 2, "stroke-linecap": "round", "stroke-linejoin": "round", "aria-hidden": "true" });
    svg.style.flex = "0 0 auto";
    svg.style.display = "block";
    const tagRe = /<(\w+)((?:\s+[\w-]+="[^"]*")*)\s*\/>/g;
    let m;
    while ((m = tagRe.exec(markup))) {
      const el = document.createElementNS(SVGNS, m[1]);
      const attrRe = /([\w-]+)="([^"]*)"/g;
      let a;
      while ((a = attrRe.exec(m[2]))) el.setAttribute(a[1], a[2]);
      svg.appendChild(el);
    }
    return svg;
  }

  /* ---------- Kolory ---------- */

  function rgb(hex) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ""));
    const n = m ? parseInt(m[1], 16) : 0x1a73e8;
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  const tint = (hex, a) => {
    const [r, g, b] = rgb(hex);
    return `rgba(${r},${g},${b},${a})`;
  };
  // Kolor tekstu czytelny na danym tle.
  const inkOn = (hex) => {
    const [r, g, b] = rgb(hex);
    return (0.299 * r + 0.587 * g + 0.114 * b) / 255 > 0.58 ? "#202124" : "#ffffff";
  };

  /* ---------- Tekst z adresami ---------- */

  const isEmail = (s) => EMAIL_RE.test(String(s || "").trim());
  const normEmail = (s) => String(s || "").trim().toLowerCase();

  // Dzieli tekst po przecinkach, średnikach i nowych liniach (ale nie wewnątrz <...>).
  function splitParts(text) {
    const parts = [];
    let cur = "";
    let depth = 0;
    for (const ch of String(text || "")) {
      if (ch === "<") depth++;
      else if (ch === ">") depth = Math.max(0, depth - 1);
      if (depth === 0 && (ch === "," || ch === ";" || ch === "\n" || ch === "\r")) {
        parts.push(cur);
        cur = "";
      } else {
        cur += ch;
      }
    }
    parts.push(cur);
    return parts.map((p) => p.trim()).filter(Boolean);
  }

  // Obsługuje: "jan@x.pl", "Jan Kowalski <jan@x.pl>", "Jan Kowalski jan@x.pl".
  function parseEntries(text) {
    const entries = [];
    let invalid = 0;
    for (const part of splitParts(text)) {
      const m = part.match(/^(.*?)<\s*([^<>\s]+)\s*>$/);
      if (m) {
        const email = normEmail(m[2]);
        if (!isEmail(email)) {
          invalid++;
          continue;
        }
        entries.push({ name: m[1].trim().replace(/^["']+|["']+$/g, ""), email });
        continue;
      }
      const tokens = part.split(/\s+/);
      const mails = tokens.filter(isEmail);
      if (!mails.length) {
        invalid++;
        continue;
      }
      if (mails.length === 1) {
        entries.push({ name: tokens.filter((t) => t !== mails[0]).join(" "), email: normEmail(mails[0]) });
      } else {
        mails.forEach((e) => entries.push({ name: "", email: normEmail(e) }));
      }
    }
    return { entries, invalid };
  }

  // Adresy z tekstu, bez powtórzeń.
  function entriesOf(text) {
    const seen = new Map();
    const out = [];
    for (const e of parseEntries(text).entries) {
      if (seen.has(e.email)) {
        const prev = seen.get(e.email);
        if (e.name && !prev.name) prev.name = e.name;
        continue;
      }
      const copy = { ...e };
      seen.set(e.email, copy);
      out.push(copy);
    }
    return out;
  }

  const fmtEntry = (e) => {
    const name = String(e.name || "").replace(/[,;<>"]/g, " ").replace(/\s+/g, " ").trim();
    return name ? `${name} <${e.email}>` : e.email;
  };

  // Dopisuje na koniec tekstu tylko te adresy, których jeszcze w nim nie ma.
  function appendToText(text, entries) {
    const have = new Set(entriesOf(text).map((e) => e.email));
    const add = [];
    for (const e of entries) {
      if (have.has(e.email)) continue;
      have.add(e.email);
      add.push(fmtEntry(e));
    }
    if (!add.length) return { text: String(text || ""), added: 0 };
    const base = String(text || "").trim().replace(/[,;]\s*$/, "");
    return { text: (base ? base + ", " : "") + add.join(", "), added: add.length };
  }

  // Do wyszukiwania: małe litery, bez polskich znaków diakrytycznych.
  const fold = (s) =>
    String(s || "")
      .toLowerCase()
      .replace(/ł/g, "l")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "");

  // Podpowiedzi z listy wpisów {name,email}: po imieniu lub adresie, bez już użytych.
  function searchEntries(entries, query, excludeSet, limit) {
    const q = fold(query).trim();
    if (!q) return [];
    const res = [];
    for (const c of entries) {
      if (excludeSet && excludeSet.has(c.email)) continue;
      const name = fold(c.name);
      const mail = fold(c.email);
      let score = -1;
      if (name.startsWith(q)) score = 0;
      else if (name.split(/\s+/).some((w) => w.startsWith(q))) score = 1;
      else if (mail.startsWith(q)) score = 2;
      else if (name.includes(q) || mail.includes(q)) score = 3;
      if (score >= 0) res.push({ c, score });
    }
    const key = (c) => fold(c.name || c.email);
    res.sort((a, b) => a.score - b.score || key(a.c).localeCompare(key(b.c)));
    return res.slice(0, limit || 6).map((r) => r.c);
  }

  const groupEmails = (g) => entriesOf(g && g.text).map((e) => e.email);

  // Podpowiedzi przy pisaniu w grupie: najpierw z głównej grupy katalogu, potem z „Wszystkich maili”.
  function gatherSuggestions(ctx, query) {
    const used = new Set(ctx.usedEmails || []);
    const all = entriesOf(ctx.mainText);
    const nameOf = new Map(all.map((e) => [e.email, e.name]));
    const folder = (ctx.folders || []).find((f) => f.id === (ctx.group && ctx.group.folderId)) || null;
    const pool = folder ? entriesOf(folder.mainText).map((e) => ({ name: e.name || nameOf.get(e.email) || "", email: e.email })) : [];
    const inFolder = searchEntries(pool, query, used, 4).map((c) => ({ ...c, section: "folder" }));
    const taken = new Set([...used, ...inFolder.map((c) => c.email)]);
    const inAll = searchEntries(all, query, taken, 6).map((c) => ({ ...c, section: "all" }));
    return { folderName: folder ? folder.name : "", items: [...inFolder, ...inAll] };
  }

  // Dopisuje adresy do głównej grupy katalogu (mutuje folders) i opcjonalnie do „Wszystkich maili”.
  function addToFolderMain(state, folderId, entries) {
    const f = state.folders.find((x) => x.id === folderId);
    if (f) f.mainText = appendToText(f.mainText, entries).text;
    return f ? f.mainText : "";
  }

  // Usuwa z tekstu wpisy, których adresy są w zbiorze (reszta zostaje).
  // Usuwa z końca tekstu po jednym wpisie na każdy adres z listy (lista może mieć powtórzenia).
  function removeEmails(text, list) {
    const need = new Map();
    (list || []).forEach((e) => need.set(e, (need.get(e) || 0) + 1));
    const parts = splitParts(text);
    for (let i = parts.length - 1; i >= 0; i--) {
      const es = parseEntries(parts[i]).entries;
      if (es.length === 1 && need.get(es[0].email) > 0) {
        need.set(es[0].email, need.get(es[0].email) - 1);
        parts.splice(i, 1);
      }
    }
    return parts.join(", ");
  }

  // Dopisuje adresy na koniec tekstu bez usuwania powtórzeń.
  function appendRaw(text, emails) {
    const base = String(text || "").trim().replace(/[,;]\s*$/, "");
    return (base ? base + ", " : "") + emails.join(", ");
  }

  /* ---------- Odczyt adresów z pliku Word (.docx = ZIP z plikami XML) ---------- */

  async function inflateRaw(bytes) {
    const ds = new DecompressionStream("deflate-raw");
    const w = ds.writable.getWriter();
    w.write(bytes);
    w.close();
    return new Uint8Array(await new Response(ds.readable).arrayBuffer());
  }

  // Zwraca { nazwa: Uint8Array } dla wybranych plików z archiwum ZIP.
  async function readZip(buf, wanted) {
    const u8 = new Uint8Array(buf);
    const dv = new DataView(buf);
    let eocd = -1;
    for (let i = u8.length - 22; i >= Math.max(0, u8.length - 65557); i--) {
      if (dv.getUint32(i, true) === 0x06054b50) {
        eocd = i;
        break;
      }
    }
    if (eocd < 0) throw new Error("To nie jest plik .docx (brak archiwum ZIP).");
    const count = dv.getUint16(eocd + 10, true);
    let p = dv.getUint32(eocd + 16, true);
    const dec = new TextDecoder();
    const out = {};
    for (let n = 0; n < count; n++) {
      if (dv.getUint32(p, true) !== 0x02014b50) break;
      const method = dv.getUint16(p + 10, true);
      const csize = dv.getUint32(p + 20, true);
      const nameLen = dv.getUint16(p + 28, true);
      const extraLen = dv.getUint16(p + 30, true);
      const commentLen = dv.getUint16(p + 32, true);
      const local = dv.getUint32(p + 42, true);
      const name = dec.decode(u8.subarray(p + 46, p + 46 + nameLen));
      p += 46 + nameLen + extraLen + commentLen;
      if (!wanted(name)) continue;
      const lh = local + 30 + dv.getUint16(local + 26, true) + dv.getUint16(local + 28, true);
      const data = u8.subarray(lh, lh + csize);
      out[name] = method === 0 ? data : method === 8 ? await inflateRaw(data) : null;
    }
    return out;
  }

  const MAIL_RE = /[A-Za-z0-9._%+\-]+@[A-Za-z0-9\-]+(?:\.[A-Za-z0-9\-]+)*\.[A-Za-z]{2,}/g;

  // Wyciąga adresy e-mail z pliku .docx (tekst, nagłówki, stopki, przypisy, komentarze i odnośniki mailto:).
  async function docxEmails(buf) {
    const files = await readZip(buf, (n) => /^word\/(document|header\d*|footer\d*|footnotes|endnotes|comments)\.xml$/.test(n) || /^word\/_rels\/.+\.rels$/.test(n));
    const dec = new TextDecoder();
    const found = [];
    const fromLinks = [];
    const ent = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'" };
    // najpierw treść główna, potem nagłówki/stopki itd.
    const order = (n) => (n === "word/document.xml" ? 0 : n.endsWith(".rels") ? 3 : 1);
    for (const [name, data] of Object.entries(files).sort((a, b) => order(a[0]) - order(b[0]) || a[0].localeCompare(b[0]))) {
      if (!data) continue;
      let xml = dec.decode(data);
      if (name.endsWith(".rels")) {
        for (const m of xml.matchAll(/Target="mailto:([^"?]+)/gi)) fromLinks.push(decodeURIComponent(m[1].replace(/&amp;/g, "&")));
        continue;
      }
      xml = xml
        .replace(/<w:(tab|br|cr)\b[^>]*\/>/g, " ")
        .replace(/<\/w:p>/g, "\n")
        .replace(/<[^>]+>/g, "")
        .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCharCode(parseInt(h, 16)))
        .replace(/&#(\d+);/g, (_, d) => String.fromCharCode(Number(d)))
        .replace(/&(amp|lt|gt|quot|apos);/g, (_, k) => ent[k]);
      for (const m of xml.matchAll(MAIL_RE)) found.push(m[0]);
    }
    // adres z odnośnika mailto: dopisujemy tylko wtedy, gdy nie ma go w tekście (żeby nie tworzyć sztucznych powtórzeń)
    const inText = new Set(found.map((r) => normEmail(r.replace(/[.,;:]+$/, ""))));
    new Set(fromLinks.map(normEmail)).forEach((e) => !inText.has(e) && found.push(e));
    // Wszystkie wystąpienia adresów, w kolejności z pliku (powtórzenia zostają).
    const emails = [];
    for (const raw of found) {
      const e = normEmail(raw.replace(/[.,;:]+$/, ""));
      if (isEmail(e)) emails.push(e);
    }
    return emails;
  }

  const newId = () => "g" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

  function nextColor(groups) {
    const used = new Set(groups.map((g) => g.color));
    return COLORS.find((c) => !used.has(c)) || COLORS[groups.length % COLORS.length];
  }

  function nextIcon(groups) {
    const used = new Set(groups.map((g) => g.icon));
    const names = iconNames().filter((n) => !/^folder/i.test(n));
    return names.find((i) => !used.has(i)) || names[0] || "mail";
  }

  // Czy odbiorcy to dokładnie któraś z istniejących list: te same osoby, tyle samo i w tej samej kolejności?
  function matchesAnyList(emails, lists) {
    return lists.some((l) => l.length > 0 && l.length === emails.length && l.every((e, i) => e === emails[i]));
  }

  /* ---------- Ikony z folderu icons/groups (skanowane w oknie rozszerzenia) ---------- */

  const readAll = (dir) =>
    new Promise((res, rej) => {
      const r = dir.createReader();
      const all = [];
      const next = () =>
        r.readEntries((es) => {
          if (!es.length) return res(all);
          all.push(...es);
          next();
        }, rej);
      next();
    });

  // Obrazki zmniejszamy do 64 px, żeby zapis w przeglądarce był mały.
  async function shrinkImage(file) {
    try {
      const bmp = await createImageBitmap(file);
      const k = Math.min(1, 64 / Math.max(bmp.width, bmp.height));
      const c = document.createElement("canvas");
      c.width = Math.max(1, Math.round(bmp.width * k));
      c.height = Math.max(1, Math.round(bmp.height * k));
      c.getContext("2d").drawImage(bmp, 0, 0, c.width, c.height);
      return c.toDataURL("image/png");
    } catch (e) {
      return new Promise((res, rej) => {
        const fr = new FileReader();
        fr.onload = () => res(fr.result);
        fr.onerror = rej;
        fr.readAsDataURL(file);
      });
    }
  }

  // Wczytuje plik ikony wybrany przez użytkownika: { t: "svg"|"img", v } albo null, gdy format nie pasuje.
  async function readIconFile(file) {
    if (/\.svg$/i.test(file.name) || file.type === "image/svg+xml") {
      if (file.size > 200000) return null;
      const text = await file.text();
      try {
        svgFromText(text, 16);
      } catch (e) {
        return null;
      }
      return { t: "svg", v: text };
    }
    if (!/^image\/(png|jpeg|webp|gif)$/.test(file.type) || file.size > 5000000) return null;
    return { t: "img", v: await shrinkImage(file) };
  }

  async function addUserIcon(file) {
    const data = await readIconFile(file);
    if (!data) return null;
    let id = "moje-" + file.name;
    for (let n = 2; userIcons[id]; n++) id = `moje-${n}-${file.name}`;
    userIcons[id] = data;
    await store.set({ userIcons });
    return id;
  }

  async function removeUserIcon(id) {
    if (!isUserIcon(id)) return;
    delete userIcons[id];
    await store.set({ userIcons });
  }

  async function scanIcons() {
    if (!(typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.getPackageDirectoryEntry)) return null;
    const root = await new Promise((r) => chrome.runtime.getPackageDirectoryEntry(r));
    const dir = await new Promise((res, rej) => root.getDirectory("icons/groups", {}, res, rej));
    const out = {};
    for (const e of await readAll(dir)) {
      if (!e.isFile || !/\.(svg|png|jpe?g|webp|gif)$/i.test(e.name)) continue;
      const file = await new Promise((res, rej) => e.file(res, rej));
      if (/\.svg$/i.test(e.name)) {
        if (file.size < 200000) out[e.name] = { t: "svg", v: await file.text() };
      } else if (file.size < 5000000) {
        out[e.name] = { t: "img", v: await shrinkImage(file) };
      }
    }
    return out;
  }

  // Wywoływane przy otwarciu okna rozszerzenia: wczytuje ikony z folderu i zapisuje je dla Gmaila.
  async function syncIcons() {
    try {
      const found = await scanIcons();
      if (!found) return;
      const d = await store.get(["iconData"]);
      if (JSON.stringify(d.iconData || {}) !== JSON.stringify(found)) await store.set({ iconData: found });
    } catch (e) {}
  }

  /* ---------- Zapis w przeglądarce ---------- */

  const store = {
    get: (keys) => new Promise((resolve) => chrome.storage.local.get(keys, resolve)),
    set: (obj) => new Promise((resolve) => chrome.storage.local.set(obj, resolve)),
    remove: (keys) => new Promise((resolve) => chrome.storage.local.remove(keys, resolve))
  };

  // Dane: mainText ("Wszystkie maile" – dawna główna lista), folders [{id, name, color, mainText}]
  // (katalogi; mainText = „Główna grupa” katalogu, czyli wszystkie adresy z tego katalogu)
  // i groups [{id, name, color, icon, text, folderId}]. Każda grupa należy do katalogu.
  // Pliki Word wczytane do listy: [{id, name, added:[adresy dodane z tego pliku]}]
  const cleanFiles = (a) =>
    (Array.isArray(a) ? a : [])
      .filter((f) => f && f.id && f.name)
      .map((f) => ({ id: f.id, name: String(f.name), added: (Array.isArray(f.added) ? f.added : []).filter(isEmail) }));

  async function load() {
    const d = await store.get(["mainText", "allFiles", "groups", "folders", "iconData", "userIcons", "customColors", "contacts", "emails"]);
    const contacts = Array.isArray(d.contacts)
      ? d.contacts
      : Array.isArray(d.emails)
      ? d.emails.filter(isEmail).map((e) => ({ name: "", email: normEmail(e) }))
      : [];
    const byEmail = new Map(contacts.map((c) => [c.email, c]));
    iconData = d.iconData && typeof d.iconData === "object" ? d.iconData : {};
    userIcons = d.userIcons && typeof d.userIcons === "object" ? d.userIcons : {};
    let changed = false;
    let mainText = d.mainText;
    if (typeof mainText !== "string") {
      mainText = contacts.map(fmtEntry).join(", ");
      changed = true;
    }
    let folders = (Array.isArray(d.folders) ? d.folders : [])
      .filter((f) => f && f.id && f.name)
      .map((f, i) => ({ id: f.id, name: String(f.name), color: f.color || COLORS[i % COLORS.length], mainText: typeof f.mainText === "string" ? f.mainText : "", files: cleanFiles(f.files) }));
    if (!folders.length) {
      folders = [{ id: newId(), name: "Ogólne", color: COLORS[1], mainText: "" }];
      changed = true;
    }
    const folderIds = new Set(folders.map((f) => f.id));
    const groups = (Array.isArray(d.groups) ? d.groups : []).map((g) => {
      const base = { id: g.id || newId(), name: g.name || "Grupa", color: g.color || COLORS[0], icon: typeof g.icon === "string" && g.icon ? g.icon : "users", files: cleanFiles(g.files) };
      let folderId = g.folderId;
      if (!folderIds.has(folderId)) {
        folderId = folders[0].id;
        changed = true;
      }
      if (typeof g.text === "string") return { ...base, folderId, text: g.text };
      changed = true;
      return { ...base, folderId, text: (g.emails || []).map((e) => fmtEntry(byEmail.get(e) || { name: "", email: e })).join(", ") };
    });
    // Główna grupa katalogu ma zawierać adresy jego grup (dopisujemy brakujące).
    folders.forEach((f) => {
      const next = appendToText(f.mainText, groups.filter((g) => g.folderId === f.id).flatMap((g) => entriesOf(g.text)));
      if (next.added) {
        f.mainText = next.text;
        changed = true;
      }
    });
    if (changed) await store.set({ mainText, groups, folders });
    if (d.contacts !== undefined || d.emails !== undefined) await store.remove(["contacts", "emails"]);
    const customColors = (Array.isArray(d.customColors) ? d.customColors : []).filter((c) => /^#[0-9a-f]{6}$/i.test(c)).slice(0, 24);
    return { mainText, groups, folders, allFiles: cleanFiles(d.allFiles), customColors };
  }

  const save = (partial) => store.set(partial);

  /* ---------- Małe okienko tworzenia / edycji grupy ---------- */

  function h(tag, props = {}, children = []) {
    const el = document.createElement(tag);
    const { style, text, on, ...attrs } = props;
    if (style) Object.assign(el.style, style);
    if (text != null) el.textContent = text;
    for (const [k, v] of Object.entries(attrs)) el.setAttribute(k, v);
    if (on) for (const [ev, fn] of Object.entries(on)) el.addEventListener(ev, fn);
    children.forEach((c) => c && el.appendChild(c));
    return el;
  }

  // opts: { title, name, icon, color, saveLabel, onSave({name,icon,color,folderId}), onCancel, onDelete,
  //         noIcon (ukryj wybór ikony), nameLabel, placeholder, folders + folderId (lista wyboru katalogu) }
  function groupForm(opts) {
    const folderList = opts.folders || [];
    const folderSel = folderList.length
      ? h("select", { style: { width: "100%", boxSizing: "border-box", padding: "8px 10px", border: "1px solid #dadce0", borderRadius: "10px", font: `14px ${FONT}`, outline: "none", color: "#202124", background: "#fff" } }, folderList.map((f) => h("option", { value: f.id, text: f.name })))
      : null;
    if (folderSel && opts.folderId) folderSel.value = opts.folderId;
    let icn = opts.icon || iconNames()[0] || "mail";
    let color = opts.color || COLORS[0];

    const pvIcon = h("span", { style: { display: "inline-flex" } });
    const pvName = h("span", { style: { flex: "1", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" } });
    const preview = h("div", { style: { display: "flex", alignItems: "center", gap: "8px", height: "34px", padding: "0 10px", font: `600 13px ${FONT}` } }, [pvIcon, pvName]);

    const nameInput = h("input", {
      type: "text",
      maxlength: "40",
      placeholder: opts.placeholder || "Do czego jest, np. Wycieczka",
      value: opts.name || "",
      style: { width: "100%", boxSizing: "border-box", padding: "9px 11px", border: "1px solid #dadce0", borderRadius: "10px", font: `14px ${FONT}`, outline: "none", color: "#202124", background: "#fff" }
    });
    nameInput.addEventListener("focus", () => {
      nameInput.style.borderColor = "#1a73e8";
      nameInput.style.boxShadow = "0 0 0 2px rgba(26,115,232,.2)";
    });
    nameInput.addEventListener("blur", () => {
      nameInput.style.borderColor = "#dadce0";
      nameInput.style.boxShadow = "none";
    });

    let iconBtns = [];
    const iconGrid = h("div", { style: { display: "flex", flexWrap: "wrap", gap: "4px", maxHeight: "118px", overflowY: "auto", padding: "2px" } });
    const iconMsg = h("div", { style: { fontSize: "11px", color: "#5f6368", minHeight: "14px", marginTop: "4px" } });
    function renderIcons() {
      iconGrid.textContent = "";
      iconBtns = iconNames().map((id) => {
        const b = h("button", {
          type: "button",
          title: iconTitle(id),
          style: { width: "28px", height: "28px", padding: "0", display: "inline-flex", alignItems: "center", justifyContent: "center", border: "1px solid #dadce0", borderRadius: "6px", background: "#fff", color: "#3c4043", cursor: "pointer" },
          on: {
            mousedown: (e) => e.preventDefault(),
            click: (e) => {
              e.preventDefault();
              icn = id;
              paint();
            }
          }
        }, [icon(id, 16)]);
        b._id = id;
        if (!isUserIcon(id)) {
          iconGrid.appendChild(b);
          return b;
        }
        // własna ikona użytkownika: po najechaniu pojawia się „×”, który ją usuwa
        const x = h("button", { type: "button", class: "gm-x", title: "Usuń tę ikonę", text: "×", on: { mousedown: (e) => e.preventDefault(), click: async (e) => {
          e.preventDefault();
          e.stopPropagation();
          await removeUserIcon(id);
          if (icn === id) icn = iconNames()[0] || "mail";
          renderIcons();
          paint();
        } } });
        iconGrid.appendChild(h("span", { class: "gm-sv" }, [b, x]));
        return b;
      });
    }
    renderIcons();
    const iconFile = h("input", { type: "file", accept: ".svg,.png,.jpg,.jpeg,.webp,.gif,image/*", multiple: "", style: { display: "none" } });
    iconFile.addEventListener("change", async () => {
      const files = [...iconFile.files];
      iconFile.value = "";
      let ok = 0;
      for (const f of files) {
        try {
          const id = await addUserIcon(f);
          if (id) {
            ok++;
            icn = id;
          }
        } catch (e) {}
      }
      iconMsg.textContent = ok ? `Dodano ikon: ${ok}.` : "Nie dodano ikony. Obsługiwane formaty: SVG, PNG, JPG, WebP, GIF.";
      renderIcons();
      paint();
    });
    const addIconBtn = h("button", { type: "button", title: "Dodaj własną ikonę z pliku (SVG, PNG, JPG, WebP, GIF)", text: "＋ dodaj ikonę", style: { padding: "3px 8px", border: "1px solid #dadce0", borderRadius: "6px", background: "#fff", color: "#1a73e8", font: `600 11px ${FONT}`, cursor: "pointer", marginTop: "6px" }, on: { mousedown: (e) => e.preventDefault(), click: (e) => { e.preventDefault(); iconFile.click(); } } });

    // okrągłe próbki koloru (jak w pierwotnej wersji) + własny kolor na końcu
    const swBtns = COLORS.map((c) => {
      const b = h("button", {
        type: "button",
        title: c,
        style: { width: "22px", height: "22px", padding: "0", border: "2px solid #fff", borderRadius: "50%", background: c, cursor: "pointer" },
        on: {
          mousedown: (e) => e.preventDefault(),
          click: (e) => {
            e.preventDefault();
            color = c;
            paint();
          }
        }
      });
      b._c = c;
      return b;
    });
    const custom = h("input", { type: "color", class: "gm-cc", title: "Własny kolor", value: color });
    custom.addEventListener("input", () => {
      color = custom.value;
      paint();
    });
    // zapisane własne kolory (wspólne dla wszystkich grup i katalogów)
    let saved = (opts.customColors || []).slice();
    const savedBox = h("span", { style: { display: "contents" } });
    const pickSaved = (c) => (e) => {
      e.preventDefault();
      color = c;
      paint();
    };
    function renderSaved() {
      savedBox.textContent = "";
      saved.forEach((c) => {
        const b = h("button", { type: "button", title: c + " (zapisany kolor)", style: { width: "22px", height: "22px", padding: "0", border: "2px solid #fff", borderRadius: "50%", background: c, cursor: "pointer" }, on: { mousedown: (e) => e.preventDefault(), click: pickSaved(c) } });
        b._c = c;
        const x = h("button", { type: "button", class: "gm-x", title: "Usuń zapisany kolor", text: "×", on: { mousedown: (e) => e.preventDefault(), click: (e) => { e.preventDefault(); e.stopPropagation(); saved = saved.filter((v) => v !== c); opts.onCustomColors && opts.onCustomColors(saved.slice()); renderSaved(); paint(); } } });
        savedBox.appendChild(h("span", { class: "gm-sv" }, [b, x]));
      });
    }
    const saveColorBtn = h("button", { type: "button", title: "Zapisz wybrany kolor, żeby użyć go ponownie", text: "＋ zapisz kolor", style: { padding: "3px 8px", border: "1px solid #dadce0", borderRadius: "6px", background: "#fff", color: "#1a73e8", font: `600 11px ${FONT}`, cursor: "pointer" }, on: { mousedown: (e) => e.preventDefault(), click: (e) => {
      e.preventDefault();
      const c = String(color).toLowerCase();
      if (!/^#[0-9a-f]{6}$/.test(c) || COLORS.includes(c) || saved.includes(c)) return;
      saved = [...saved, c].slice(-24);
      opts.onCustomColors && opts.onCustomColors(saved.slice());
      renderSaved();
      paint();
    } } });
    const swRow = h("div", { style: { display: "flex", gap: "7px", flexWrap: "wrap", alignItems: "center", padding: "2px" } }, [...swBtns, savedBox, custom, saveColorBtn]);
    renderSaved();
    const css = h("style", {
      text: ".gm-cc{width:26px;height:26px;padding:0;border:0;background:none;cursor:pointer;border-radius:50%}.gm-cc::-webkit-color-swatch-wrapper{padding:0}.gm-sv{position:relative;display:inline-flex}.gm-sv .gm-x{display:none;position:absolute;top:-6px;right:-6px;width:14px;height:14px;border:0;border-radius:50%;background:#202124;color:#fff;font:11px/14px sans-serif;padding:0;cursor:pointer}.gm-sv:hover .gm-x{display:block}.gm-cc::-webkit-color-swatch{border:2px solid #fff;border-radius:50%;box-shadow:0 0 0 1px #dadce0}"
    });

    function paint() {
      preview.style.background = color;
      preview.style.color = inkOn(color);
      pvIcon.textContent = "";
      pvIcon.appendChild(icon(icn, 18));
      pvName.textContent = nameInput.value.trim() || opts.nameLabel || "Nazwa grupy";
      iconBtns.forEach((b) => {
        const on = b._id === icn;
        b.style.boxShadow = on ? `0 0 0 2px ${color}` : "none";
        b.style.background = on ? tint(color, 0.18) : "#fff";
      });
      const lc = String(color).toLowerCase();
      const preset = COLORS.includes(color) || saved.includes(lc);
      swBtns.forEach((b) => {
        b.style.boxShadow = b._c === color ? "0 0 0 2px #202124" : "0 0 0 1px #dadce0";
      });
      savedBox.querySelectorAll("button[title$='(zapisany kolor)']").forEach((b) => {
        b.style.boxShadow = b._c === lc ? "0 0 0 2px #202124" : "0 0 0 1px #dadce0";
      });
      const canSave = /^#[0-9a-f]{6}$/.test(lc) && !preset;
      saveColorBtn.style.display = canSave ? "" : "none";
      if (/^#[0-9a-f]{6}$/i.test(color)) custom.value = color;
      custom.style.boxShadow = preset ? "none" : "0 0 0 2px #202124";
    }

    const submit = () => opts.onSave({ name: nameInput.value.trim(), icon: icn, color, folderId: folderSel ? folderSel.value : opts.folderId || null });
    nameInput.addEventListener("input", paint);
    nameInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        submit();
      }
    });

    const btnBase = { padding: "7px 14px", font: `600 13px ${FONT}`, borderRadius: "6px", cursor: "pointer" };
    const saveB = h("button", { type: "button", text: opts.saveLabel || "Zapisz", style: { ...btnBase, border: "1px solid #1a73e8", background: "#1a73e8", color: "#fff" }, on: { click: submit } });
    const cancelB = h("button", { type: "button", text: "Anuluj", style: { ...btnBase, border: "1px solid #dadce0", background: "#fff", color: "#1a73e8" }, on: { click: () => opts.onCancel && opts.onCancel() } });
    const buttons = [saveB];
    if (opts.onDelete) {
      buttons.push(h("button", { type: "button", text: "Usuń", style: { ...btnBase, border: "1px solid #dadce0", background: "#fff", color: "#b3261e" }, on: { click: () => opts.onDelete() } }));
      cancelB.style.marginLeft = "auto";
    }
    buttons.push(cancelB);

    const labelStyle = { fontSize: "13px", fontWeight: "600", color: "#202124", marginBottom: "6px" };
    const root = h("div", { style: { padding: "12px", display: "flex", flexDirection: "column", gap: "12px", font: `13px ${FONT}`, color: "#202124", textAlign: "left" } }, [
      css,
      opts.title ? h("div", { style: { fontSize: "12px", fontWeight: "600", color: "#5f6368" }, text: opts.title }) : null,
      preview,
      h("div", {}, [h("div", { style: labelStyle, text: opts.nameLabel || "Nazwa grupy" }), nameInput]),
      folderSel ? h("div", {}, [h("div", { style: labelStyle, text: "Katalog" }), folderSel]) : null,
      h("div", {}, [h("div", { style: labelStyle, text: "Kolor" }), swRow]),
      opts.noIcon ? null : h("div", {}, [h("div", { style: labelStyle, text: "Ikona" }), iconGrid, addIconBtn, iconFile, iconMsg]),
      h("div", { style: { display: "flex", gap: "8px" } }, buttons)
    ]);
    paint();
    root.focusName = () => nameInput.focus();
    return root;
  }

  const GM = {
    ALL_NAME,
    ALL_COLOR,
    mainLabel,
    gatherSuggestions,
    addToFolderMain,
    removeEmails,
    appendRaw,
    syncIcons,
    iconNames,
    addUserIcon,
    removeUserIcon,
    docxEmails,
    COLORS,
    ICONS,
    GROUP_ICONS,
    FONT,
    icon,
    tint,
    inkOn,
    h,
    groupForm,
    isEmail,
    normEmail,
    parseEntries,
    entriesOf,
    fmtEntry,
    appendToText,
    groupEmails,
    newId,
    nextColor,
    nextIcon,
    matchesAnyList,
    fold,
    searchEntries,
    load,
    save
  };

  root.GM = GM;
  if (typeof module !== "undefined" && module.exports) module.exports = GM;
})(typeof globalThis !== "undefined" ? globalThis : this);
