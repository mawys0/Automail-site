// Skrypt działający w Gmailu: przyciski przy polu "Do", menu grup i tworzenie grup.
(() => {
  if (window.__listaOdbiorcowLoaded) return;
  window.__listaOdbiorcowLoaded = true;

  const MIN_GROUP = 2; // od ilu odbiorców proponujemy utworzenie grupy
  const FONT = "'Google Sans', Roboto, Arial, sans-serif";
  const WIDGET_ATTR = "data-gm-widget";
  const CHIP_SEL = "[data-hovercard-id], [email]";
  const OTHER_FIELD_RE = /(\bcc\b|bcc|udw|\bdw\b|kopi|wiadomo)/i;

  const TO_SELECTORS = [
    'input[aria-label="Do odbiorców"]',
    'input[aria-label="Odbiorcy"]',
    'input[aria-label="To recipients"]',
    'input[aria-label="Recipients"]',
    'div[name="to"] input'
  ];

  let state = { mainText: "", groups: [], folders: [] };
  const widgets = new Map(); // pole "Do" -> { wrap, pickBtn, createBtn }
  let popover = null;

  /* ---------- Pomocnicze ---------- */

  function h(tag, props = {}, children = []) {
    const el = document.createElement(tag);
    const { style, text, on, ...attrs } = props;
    if (style) Object.assign(el.style, style);
    if (text != null) el.textContent = text;
    for (const [k, v] of Object.entries(attrs)) el.setAttribute(k, v);
    if (on) for (const [ev, fn] of Object.entries(on)) el.addEventListener(ev, fn);
    children.forEach((c) => c && el.appendChild(c));
    return el;
  }

  function findToInputs() {
    const found = new Set();
    TO_SELECTORS.forEach((sel) => document.querySelectorAll(sel).forEach((el) => found.add(el)));
    // Zapas dla innych języków: pierwsze pole z peoplekit-id w oknie wiadomości to zwykle "Do".
    const seenForms = new Set();
    document.querySelectorAll("input[peoplekit-id]").forEach((el) => {
      const form = el.closest("form") || document.body;
      if (seenForms.has(form)) return;
      seenForms.add(form);
      found.add(el);
    });
    return [...found];
  }

  /* ---------- Odczyt odbiorców z pola "Do" ---------- */

  function hasOtherRecipientField(root, input) {
    return [...root.querySelectorAll("input[aria-label], textarea[aria-label]")].some(
      (f) => f !== input && OTHER_FIELD_RE.test(f.getAttribute("aria-label") || "")
    );
  }

  function recipientScope(input) {
    const row = input.closest(".aoD");
    if (row) return row;
    let node = input.parentElement;
    for (let i = 0; i < 6; i++) {
      const up = node && node.parentElement;
      if (!up || up.tagName === "FORM" || up.getAttribute("role") === "dialog" || hasOtherRecipientField(up, input)) break;
      node = up;
      if (node.querySelector(CHIP_SEL)) break;
    }
    return node;
  }

  function getRecipients(input) {
    const map = new Map();
    const scope = recipientScope(input);
    if (scope) {
      scope.querySelectorAll(CHIP_SEL).forEach((el) => {
        const raw = el.getAttribute("data-hovercard-id") || el.getAttribute("email") || "";
        const email = GM.normEmail(raw);
        if (GM.isEmail(email) && !map.has(email)) map.set(email, el.getAttribute("data-name") || "");
      });
    }
    // adresy wpisane, ale jeszcze nie zamienione w "chipy"
    GM.parseEntries(input.value || "").entries.forEach((e) => {
      if (!map.has(e.email)) map.set(e.email, e.name);
    });
    return [...map].map(([email, name]) => ({ email, name }));
  }

  const wait = (ms) => new Promise((r) => setTimeout(r, ms));

  // Czy w polu „Do” został niezatwierdzony tekst z adresami (czyli nie stał się „chipem”).
  const hasRawText = (input) => /@/.test(input.value || input.textContent || "");

  function pressEnter(input) {
    ["keydown", "keypress", "keyup"].forEach((type) =>
      input.dispatchEvent(new KeyboardEvent(type, { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true, cancelable: true }))
    );
  }

  // Wstawia adresy tak, żeby Gmail zamienił je w „chipy” (okrągłe plakietki odbiorców):
  // 1) symulowane wklejenie listy (tak Gmail rozpoznaje wklejone adresy),
  // 2) gdy Gmail go nie obsłuży – wpisanie tekstu z przecinkami,
  // 3) gdy adresy nadal są zwykłym tekstem – Enter, a na końcu opuszczenie i ponowne wejście w pole.
  async function fillRecipients(input, emails) {
    const text = emails.join(", ") + ", ";
    input.focus();
    let handled = false;
    try {
      const dt = new DataTransfer();
      dt.setData("text/plain", text);
      handled = !input.dispatchEvent(new ClipboardEvent("paste", { clipboardData: dt, bubbles: true, cancelable: true })); // false = Gmail przejął wklejenie
    } catch (e) {}
    await wait(120);
    if (!handled && !emails.every((e) => (input.value || "").includes(e)) && !getRecipients(input).some((r) => emails.includes(r.email))) {
      const ok = typeof document.execCommand === "function" && document.execCommand("insertText", false, text);
      if (!ok) {
        input.value += text;
        input.dispatchEvent(new Event("input", { bubbles: true }));
      }
      await wait(120);
    }
    if (hasRawText(input)) {
      pressEnter(input);
      await wait(150);
    }
    if (hasRawText(input)) {
      input.blur();
      await wait(150);
      input.focus();
    }
  }

  /* ---------- Przyciski ---------- */

  function pillStyle(filled) {
    return {
      padding: "3px 10px",
      font: `500 12px ${FONT}`,
      lineHeight: "18px",
      cursor: "pointer",
      borderRadius: "14px",
      border: filled ? "1px solid #1a73e8" : "1px solid #dadce0",
      background: filled ? "#1a73e8" : "#fff",
      color: filled ? "#fff" : "#1a73e8",
      verticalAlign: "middle"
    };
  }

  function makeBtn(text, filled, title, onClick) {
    const base = filled ? "#1a73e8" : "#fff";
    const hover = filled ? "#1558b0" : "#f6f9fe";
    const b = h("button", {
      type: "button",
      title,
      text,
      style: pillStyle(filled),
      on: {
        mousedown: (e) => e.preventDefault(), // nie zabieraj fokusu z okna wiadomości
        mouseenter: () => (b.style.background = hover),
        mouseleave: () => (b.style.background = base),
        click: (e) => {
          e.preventDefault();
          e.stopPropagation();
          onClick(b);
        }
      }
    });
    return b;
  }

  function flash(btn, text, ms = 1700) {
    if (btn._flashTimer) clearTimeout(btn._flashTimer);
    if (btn._label === undefined) btn._label = btn.textContent;
    btn.textContent = text;
    btn._flashTimer = setTimeout(() => {
      btn.textContent = btn._label;
      btn._label = undefined;
      btn._flashTimer = null;
    }, ms);
  }

  /* ---------- Okienka (menu i tworzenie listy) ---------- */

  function closePopover() {
    if (!popover) return;
    popover.remove();
    popover = null;
    document.removeEventListener("mousedown", onDocDown, true);
    document.removeEventListener("keydown", onKey, true);
  }

  function onDocDown(e) {
    if (!popover) return;
    if (popover.contains(e.target) || (popover._anchor && popover._anchor.contains(e.target))) return;
    closePopover();
  }

  function onKey(e) {
    if (e.key === "Escape" && popover) {
      e.stopPropagation();
      closePopover();
    }
  }

  function openPopover(anchor, width, content) {
    closePopover();
    popover = h(
      "div",
      {
        style: {
          position: "fixed",
          zIndex: "2147483000",
          width: width + "px",
          maxHeight: "380px",
          overflowY: "auto",
          background: "#fff",
          color: "#202124",
          border: "1px solid #dadce0",
          borderRadius: "8px",
          boxShadow: "0 4px 16px rgba(0,0,0,.22)",
          font: `13px ${FONT}`,
          textAlign: "left"
        }
      },
      [content]
    );
    popover._anchor = anchor;
    // klawisze w okienku nie mogą uruchamiać skrótów Gmaila
    ["keydown", "keyup", "keypress"].forEach((ev) => popover.addEventListener(ev, (e) => e.stopPropagation()));
    document.body.appendChild(popover);

    const r = anchor.getBoundingClientRect();
    const w = popover.offsetWidth;
    const hgt = popover.offsetHeight;
    const left = Math.min(Math.max(8, r.left), Math.max(8, window.innerWidth - w - 8));
    let top = r.bottom + 4;
    if (top + hgt > window.innerHeight - 8) top = Math.max(8, r.top - hgt - 4);
    popover.style.left = left + "px";
    popover.style.top = top + "px";

    document.addEventListener("mousedown", onDocDown, true);
    document.addEventListener("keydown", onKey, true);
  }

  const headStyle = { padding: "10px 12px 6px", fontWeight: "600", fontSize: "12px", color: "#5f6368" };

  function badge(iconId, color) {
    return h("span", { style: { width: "24px", height: "24px", flex: "0 0 24px", display: "inline-flex", alignItems: "center", justifyContent: "center", borderRadius: "4px", background: color, color: GM.inkOn(color) } }, [GM.icon(iconId, 15)]);
  }

  /* ---------- Menu: Wybierz grupę ---------- */

  function insertEmails(input, w, emails, btn = w.pickBtn) {
    const present = new Set(getRecipients(input).map((r) => r.email));
    const toAdd = [...new Set(emails.map((e) => GM.normEmail(e)))].filter((e) => GM.isEmail(e) && !present.has(e));
    if (!toAdd.length) {
      flash(btn, "Już wszyscy dodani");
      return;
    }
    flash(btn, `✓ Dodano ${toAdd.length}`);
    fillRecipients(input, toAdd).finally(() => {
      // Gmail zamienia adresy w "chipy" z opóźnieniem – sprawdzamy ponownie, gdy się ustabilizuje.
      setTimeout(refreshAll, 300);
      setTimeout(refreshAll, 1200);
    });
  }

  /* ---------- Wklej z Worda (.docx) ---------- */

  function pickDocx(input, w, btn) {
    const f = h("input", { type: "file", accept: ".docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document", style: { display: "none" } });
    f.addEventListener("change", async () => {
      const file = f.files && f.files[0];
      f.remove();
      if (!file) return;
      flash(btn, "Czytam plik…", 8000);
      let emails;
      try {
        emails = await GM.docxEmails(await file.arrayBuffer());
      } catch (e) {
        flash(btn, "To nie jest plik .docx", 2600);
        return;
      }
      if (!emails.length) {
        flash(btn, "Brak adresów w pliku", 2600);
        return;
      }
      insertEmails(input, w, emails, btn);
    });
    document.body.appendChild(f);
    f.click();
  }

  const emptyText = (t) => h("div", { style: { padding: "8px 12px 12px", color: "#5f6368", fontSize: "12px", lineHeight: "1.4" }, text: t });

  function pickRow(input, w, it) {
    const row = h(
      "div",
      {
        style: { display: "flex", alignItems: "center", gap: "8px", padding: "6px 12px", cursor: "pointer" },
        on: {
          mousedown: (e) => e.preventDefault(),
          mouseenter: () => (row.style.background = "#f6f9fe"),
          mouseleave: () => (row.style.background = "transparent"),
          click: () => {
            closePopover();
            insertEmails(input, w, it.emails);
          }
        }
      },
      [
        badge(it.icon, it.color),
        h("span", { style: { flex: "1", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }, text: it.label }),
        h("span", { style: { color: "#5f6368", fontSize: "12px" }, text: String(it.emails.length) })
      ]
    );
    return row;
  }

  // Menu: po lewej wąska kolumna katalogów, po prawej „Wszystkie maile” (czarny wiersz),
  // główna grupa wybranego katalogu i jego grupy.
  function buildPickContent(input, w) {
    const allEmails = GM.entriesOf(state.mainText).map((e) => e.email);
    const folders = state.folders;
    let sel = (folders.find((f) => state.groups.some((g) => g.folderId === f.id)) || folders[0] || {}).id;

    const left = h("div", { style: { width: "78px", flex: "0 0 78px", background: "#f1f3f4", borderRight: "1px solid #dadce0" } });
    const right = h("div", { style: { flex: "1", minWidth: "0", paddingBottom: "6px" } });

    function paint() {
      left.textContent = "";
      right.textContent = "";
      left.appendChild(h("div", { style: { padding: "10px 4px 6px", fontSize: "11px", fontWeight: "600", textAlign: "center", color: "#5f6368" }, text: "Katalogi" }));
      folders.forEach((f) => {
        const on = f.id === sel;
        const tile = h(
          "div",
          {
            style: {
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              gap: "2px",
              minHeight: "52px",
              padding: "6px 4px",
              borderBottom: "2px solid #f1f3f4",
              cursor: "pointer",
              textAlign: "center",
              fontSize: "11px",
              fontWeight: "600",
              lineHeight: "1.15",
              overflowWrap: "anywhere",
              color: "#202124",
              background: GM.tint(f.color, on ? 0.5 : 0.28),
              boxShadow: on ? "inset 4px 0 0 rgba(0,0,0,.45)" : "none"
            },
            on: {
              mousedown: (e) => e.preventDefault(),
              click: () => {
                sel = f.id;
                paint();
              }
            }
          },
          [on ? h("span", { style: { fontSize: "9px", fontWeight: "700", textTransform: "uppercase", opacity: ".75" }, text: "aktualnie" }) : null, h("span", { text: f.name })]
        );
        tile.title = f.name;
        left.appendChild(tile);
      });

      const cur = folders.find((f) => f.id === sel);
      right.appendChild(h("div", { style: headStyle, text: "Wybierz grupę" }));
      if (allEmails.length) right.appendChild(pickRow(input, w, { label: GM.ALL_NAME, icon: "mail", color: GM.ALL_COLOR, emails: allEmails }));
      if (cur) {
        const mainEmails = GM.entriesOf(cur.mainText).map((e) => e.email);
        right.appendChild(h("div", { style: { height: "6px" } }));
        if (mainEmails.length) right.appendChild(pickRow(input, w, { label: GM.mainLabel(cur), icon: "folder", color: cur.color, emails: mainEmails }));
        const gs = state.groups.filter((g) => g.folderId === cur.id);
        gs.forEach((g) => right.appendChild(pickRow(input, w, { label: g.name, icon: g.icon, color: g.color, emails: GM.groupEmails(g) })));
        if (!gs.length && !mainEmails.length) right.appendChild(emptyText("W tym katalogu nie ma jeszcze grup."));
      } else if (!allEmails.length) {
        right.appendChild(emptyText("Brak adresów i grup. Dodaj je w ikonie rozszerzenia."));
      }
    }
    paint();
    return h("div", {}, [h("div", { style: { display: "flex", alignItems: "stretch", minHeight: "190px" } }, [left, right])]);
  }

  /* ---------- Okienko: Stwórz grupę ---------- */

  function buildCreateContent(input, w) {
    const rec = getRecipients(input);
    const have = new Set(GM.entriesOf(state.mainText).map((e) => e.email));
    const fresh = rec.filter((r) => !have.has(r.email)).length;
    const entries = rec.map((r) => ({ email: r.email, name: r.name && !r.name.includes("@") ? r.name : "" }));

    const form = GM.groupForm({
      customColors: state.customColors || [],
      onCustomColors: (c) => {
        state.customColors = c;
        GM.save({ customColors: c });
      },
      title: "Nowa grupa z odbiorców",
      name: "",
      icon: GM.nextIcon(state.groups),
      color: GM.nextColor(state.groups),
      folders: state.folders,
      folderId: state.folders[0] && state.folders[0].id,
      saveLabel: "Zapisz grupę",
      onCancel: closePopover,
      onSave: async (v) => {
        const name = v.name || `Grupa ${state.groups.length + 1}`;
        const merged = GM.appendToText(state.mainText, entries); // „Wszystkie maile”
        const next = { mainText: merged.text, folders: state.folders.map((f) => ({ ...f })) };
        GM.addToFolderMain(next, v.folderId, entries); // główna grupa wybranego katalogu
        const groups = [...state.groups, { id: GM.newId(), name, icon: v.icon, color: v.color, text: entries.map(GM.fmtEntry).join(", "), folderId: v.folderId }];
        state = { ...state, mainText: merged.text, groups, folders: next.folders };
        await GM.save({ mainText: merged.text, groups, folders: next.folders });
        closePopover();
        refreshAll();
        flash(w.pickBtn, `✓ Zapisano „${name}”`);
      }
    });

    const info = `${rec.length} adresów` + (fresh ? `, w tym ${fresh} nowych (trafią też do „${GM.ALL_NAME}”)` : `, wszystkie są już w „${GM.ALL_NAME}”`) + ". Trafią też do głównej grupy wybranego katalogu.";
    setTimeout(() => form.focusName(), 0);
    return h("div", {}, [h("div", { style: { padding: "8px 10px 0", fontSize: "12px", color: "#5f6368", lineHeight: "1.4" }, text: info }), form]);
  }

  /* ---------- Wstrzykiwanie przycisków i odświeżanie ---------- */

  function togglePopover(anchor, width, build) {
    if (popover && popover._anchor === anchor) {
      closePopover();
      return;
    }
    openPopover(anchor, width, build());
  }

  function inject() {
    findToInputs().forEach((input) => {
      if (widgets.has(input)) return;
      const host = input.closest("td") || input.parentElement;
      if (!host || host.querySelector(`[${WIDGET_ATTR}]`)) return;

      const w = {};
      w.pickBtn = makeBtn("Wybierz grupę ▾", false, "Wybierz grupę i wklej adresy do pola Do", (btn) =>
        togglePopover(btn, 400, () => buildPickContent(input, w))
      );
      w.wordBtn = makeBtn("Wklej z Worda", false, "Wczytaj adresy z pliku Word (.docx) i wklej je do pola Do", (btn) => pickDocx(input, w, btn));
      w.createBtn = makeBtn("Stwórz grupę", true, "Zapisz obecnych odbiorców jako nową grupę", (btn) =>
        togglePopover(btn, 280, () => buildCreateContent(input, w))
      );
      w.createBtn.style.display = "none";
      w.wrap = h("span", { [WIDGET_ATTR]: "1", style: { display: "inline-flex", gap: "6px", marginLeft: "8px", verticalAlign: "middle" } }, [w.pickBtn, w.createBtn, w.wordBtn]);
      host.appendChild(w.wrap);
      widgets.set(input, w);
    });
  }

  function refreshWidget(input, w) {
    const emails = getRecipients(input).map((r) => r.email);
    // Grupa ma sens, gdy odbiorców jest sporo i nie są dokładnie sumą istniejących grup.
    // Przycisk znika tylko wtedy, gdy odbiorcy to dokładnie istniejąca lista (główna albo grupa):
    // te same osoby, tyle samo i w tej samej kolejności. Brak kogoś, nadmiar lub inna kolejność = można stworzyć nową grupę.
    const lists = [GM.entriesOf(state.mainText).map((e) => e.email), ...state.folders.map((f) => GM.entriesOf(f.mainText).map((e) => e.email)), ...state.groups.map((g) => GM.groupEmails(g))];
    // Poniżej MIN_GROUP odbiorców przycisk pokazujemy tylko, gdy to wygląda na okrojoną grupę
    // (wszyscy odbiorcy należą do jednej istniejącej grupy, np. po usunięciu osób z wklejonej grupy).
    const groupLists = state.groups.map((g) => GM.groupEmails(g));
    const trimmedGroup = emails.length >= 1 && groupLists.some((l) => emails.every((e) => l.includes(e)));
    const show = (emails.length >= MIN_GROUP || trimmedGroup) && !GM.matchesAnyList(emails, lists);
    const display = show ? "inline-block" : "none";
    if (w.createBtn.style.display !== display) w.createBtn.style.display = display;
    if (show && !w.createBtn._flashTimer) {
      const text = `Stwórz grupę (${emails.length})`;
      if (w.createBtn.textContent !== text) w.createBtn.textContent = text;
    }
  }

  function refreshAll() {
    for (const [input, w] of [...widgets]) {
      if (!input.isConnected) {
        w.wrap.remove();
        widgets.delete(input);
        continue;
      }
      refreshWidget(input, w);
    }
  }

  function reloadState() {
    return GM.load()
      .then((s) => {
        state = s;
        refreshAll();
      })
      .catch(() => {});
  }

  // Gmail ładuje okna dynamicznie, więc obserwujemy zmiany w DOM (z opóźnieniem).
  let timer = null;
  new MutationObserver(() => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      inject();
      refreshAll();
    }, 300);
  }).observe(document.body, { childList: true, subtree: true });

  // Także przy ręcznym wpisywaniu adresów w polu "Do" (zmiany w polu nie zawsze zmieniają drzewo DOM).
  let typingTimer = null;
  const onTyping = () => {
    clearTimeout(typingTimer);
    typingTimer = setTimeout(refreshAll, 250);
  };
  document.addEventListener("input", onTyping, true);
  document.addEventListener("keyup", onTyping, true);
  document.addEventListener("focusout", onTyping, true);
  document.addEventListener("click", onTyping, true); // np. kliknięcie „×” przy odbiorcy

  try {
    chrome.storage.onChanged.addListener(reloadState);
  } catch (e) {}

  reloadState().then(inject);
  inject();
})();
